# Dath Reader Android — fresh build

This project wraps the supplied Dath Reader HTML UI in a native Android WebView shell.

## GitHub
Upload the contents of this folder to a repository, preserving `.github/workflows/build-apk.yml`.
Then open **Actions → Build Dath Reader APK → Run workflow**.
The APK will appear under the workflow run's **Artifacts** section.

## Architecture
- `android/app/src/main/assets/index.html` — the supplied Dath Reader UI and PDF.js viewer.
- Native WebView shell — provides Android PDF file selection.
- `WebViewAssetLoader` — serves the HTML from a secure local origin.
- Java 17 / Gradle 8.9 / Android Gradle Plugin 8.7.3.

## Current scope
The first Android build preserves the supplied web UI. Native export/print/share integration and true existing-PDF text editing are separate implementation steps.
