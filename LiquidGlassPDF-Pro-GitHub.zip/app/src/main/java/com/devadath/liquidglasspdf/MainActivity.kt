package com.devadath.liquidglasspdf

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.io.FileOutputStream
import kotlin.math.roundToInt

data class TextOverlay(
    val id: Long,
    val page: Int,
    val text: String,
    val x: Float,
    val y: Float,
    val size: Float = 22f
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LiquidGlassPdfPro() }
    }
}

@Composable
fun LiquidGlassPdfPro() {
    var uri by remember { mutableStateOf<Uri?>(null) }
    var dark by remember { mutableStateOf(true) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) {
        if (it != null) uri = it
    }

    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(
            background = Color(0xFF080A10),
            surface = Color(0xFF101522),
            primary = Color(0xFFCDBBFF)
        ) else lightColorScheme(
            background = Color(0xFFF1F3F8),
            primary = Color(0xFF6750A4)
        )
    ) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    listOf(Color(0x665F6FFF), Color(0x3328D5B0), MaterialTheme.colorScheme.background),
                    radius = 1250f
                )
            )
        ) {
            if (uri == null) {
                val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { picked ->
                    if (picked != null) uri = picked
                }
                Home(dark, { dark = !dark }) { picker.launch(arrayOf("application/pdf")) }
            } else Viewer(uri!!, dark, { dark = !dark }, { uri = null })
        }
    }
}

@Composable
private fun Home(dark: Boolean, toggle: () -> Unit, openPdf: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(34.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("Liquid Glass", fontSize = 31.sp, fontWeight = FontWeight.Bold)
                Text("PDF Pro", fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface.copy(.6f))
            }
            IconButton(onClick = toggle) {
                Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, null)
            }
        }
        Spacer(Modifier.weight(1f))
        Glass(Modifier.fillMaxWidth()) {
            Icon(Icons.Default.PictureAsPdf, null, Modifier.size(76.dp))
            Spacer(Modifier.height(18.dp))
            Text("Your PDF workspace", fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Text("Open, zoom, rotate, annotate with text, and export.", color = MaterialTheme.colorScheme.onSurface.copy(.62f))
            Spacer(Modifier.height(22.dp))
            Button(
                onClick = openPdf,
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) {
                Icon(Icons.Default.FolderOpen, null)
                Spacer(Modifier.width(8.dp))
                Text("Open PDF")
            }
        }
        Spacer(Modifier.weight(1f))
        Text("LIQUID GLASS PDF PRO • 2.0", fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(.42f))
    }
}

@Composable
private fun Viewer(uri: Uri, dark: Boolean, toggle: () -> Unit, back: () -> Unit) {
    val context = LocalContext.current
    var renderer by remember { mutableStateOf<PdfRenderer?>(null) }
    var pfd by remember { mutableStateOf<ParcelFileDescriptor?>(null) }
    var page by remember { mutableIntStateOf(0) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var rotation by remember { mutableIntStateOf(0) }
    var editMode by remember { mutableStateOf(false) }
    var overlays by remember { mutableStateOf(listOf<TextOverlay>()) }
    var dialog by remember { mutableStateOf(false) }
    var jumpDialog by remember { mutableStateOf(false) }
    var fitWidth by remember { mutableStateOf(false) }
    var exportUri by remember { mutableStateOf<Uri?>(null) }

    val createDoc = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { out ->
        if (out != null) {
            exportFlattenedPdf(context, uri, out, overlays, renderer?.pageCount ?: 0)
        }
    }

    LaunchedEffect(uri) {
        val d = context.contentResolver.openFileDescriptor(uri, "r")
        if (d != null) {
            pfd = d
            renderer = PdfRenderer(d)
        }
    }
    DisposableEffect(Unit) {
        onDispose { renderer?.close(); pfd?.close() }
    }

    val count = renderer?.pageCount ?: 0

    Column(Modifier.fillMaxSize()) {
        GlassTop {
            IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, null) }
            Text("Liquid Glass PDF", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            IconButton(onClick = { editMode = !editMode }) {
                Icon(if (editMode) Icons.Default.EditOff else Icons.Default.Edit, null)
            }
            IconButton(onClick = { createDoc.launch("edited.pdf") }) { Icon(Icons.Default.Save, null) }
            IconButton(onClick = { share(context, uri) }) { Icon(Icons.Default.Share, null) }
            IconButton(onClick = toggle) { Icon(Icons.Default.Brightness6, null) }
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SmallTool("Edit text", Icons.Default.TextFields, editMode) { dialog = true }
            SmallTool("Jump", Icons.Default.FindInPage) { jumpDialog = true }
            SmallTool("Rotate", Icons.Default.RotateRight) { rotation = (rotation + 90) % 360 }
            SmallTool("Fit", Icons.Default.FitScreen, fitWidth) { fitWidth = !fitWidth }
            SmallTool("Reset", Icons.Default.Refresh) { zoom = 1f; rotation = 0 }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (renderer != null && count > 0) {
                PageCanvas(renderer!!, page, zoom, rotation, fitWidth, overlays, editMode) { id, dx, dy ->
                    overlays = overlays.map {
                        if (it.id == id) it.copy(x = it.x + dx, y = it.y + dy) else it
                    }
                }
            } else {
                CircularProgressIndicator(Modifier.align(Alignment.Center))
            }

            if (editMode) {
                FloatingActionButton(
                    onClick = { dialog = true },
                    modifier = Modifier.align(Alignment.BottomEnd).padding(18.dp)
                ) { Icon(Icons.Default.Add, null) }
            }
        }

        GlassBottom {
            IconButton(onClick = { page = (page - 1).coerceAtLeast(0) }) {
                Icon(Icons.Default.ChevronLeft, null)
            }
            Text("${page + 1} / $count", Modifier.width(72.dp), fontWeight = FontWeight.SemiBold)
            Slider(
                value = page.toFloat(),
                onValueChange = { page = it.roundToInt().coerceIn(0, (count - 1).coerceAtLeast(0)) },
                valueRange = 0f..(count - 1).coerceAtLeast(0).toFloat(),
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { page = (page + 1).coerceAtMost(count - 1) }) {
                Icon(Icons.Default.ChevronRight, null)
            }
            IconButton(onClick = { zoom = (zoom - .25f).coerceIn(.5f, 4f) }) { Icon(Icons.Default.ZoomOut, null) }
            Text("${(zoom * 100).roundToInt()}%", fontSize = 12.sp)
            IconButton(onClick = { zoom = (zoom + .25f).coerceIn(.5f, 4f) }) { Icon(Icons.Default.ZoomIn, null) }
        }
    }

    if (dialog) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { dialog = false },
            title = { Text("Add / edit text") },
            text = {
                OutlinedTextField(text, { text = it }, label = { Text("Text") })
            },
            confirmButton = {
                TextButton(onClick = {
                    if (text.isNotBlank()) {
                        overlays = overlays + TextOverlay(
                            System.currentTimeMillis(), page, text, .15f, .18f
                        )
                    }
                    dialog = false
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { dialog = false }) { Text("Cancel") } }
        )
    }

    if (jumpDialog) {
        var value by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { jumpDialog = false },
            title = { Text("Go to page") },
            text = { OutlinedTextField(value, { value = it.filter(Char::isDigit) }, label = { Text("Page number") }) },
            confirmButton = {
                TextButton(onClick = {
                    value.toIntOrNull()?.let { page = (it - 1).coerceIn(0, count - 1) }
                    jumpDialog = false
                }) { Text("Go") }
            }
        )
    }
}

@Composable
private fun PageCanvas(
    renderer: PdfRenderer, pageIndex: Int, zoom: Float, rotation: Int, fitWidth: Boolean,
    overlays: List<TextOverlay>, editMode: Boolean,
    move: (Long, Float, Float) -> Unit
) {
    var bitmap by remember(pageIndex, rotation) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(pageIndex, rotation) {
        val p = renderer.openPage(pageIndex)
        val scale = 2
        val b = Bitmap.createBitmap(
            p.width * scale, p.height * scale, Bitmap.Config.ARGB_8888
        )
        b.eraseColor(android.graphics.Color.WHITE)
        p.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        p.close()
        bitmap = b
    }

    val b = bitmap ?: return
    val pageOverlays = overlays.filter { it.page == pageIndex }

    Box(
        Modifier.fillMaxSize()
            .verticalScroll(rememberScrollState())
            .horizontalScroll(rememberScrollState())
            .pointerInput(Unit) {
                detectTransformGestures { _, _, z, _ ->
                    // Zoom is intentionally controlled by the bottom controls to keep edit dragging stable.
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.wrapContentSize()) {
            androidx.compose.foundation.Image(
                b.asImageBitmap(), null,
                Modifier
                    .graphicsLayer(scaleX = zoom, scaleY = zoom, rotationZ = rotation.toFloat())
                    .padding(12.dp),
                contentScale = ContentScale.Fit
            )
            pageOverlays.forEach { item ->
                TextOverlayChip(item, editMode) { dx, dy -> move(item.id, dx, dy) }
            }
        }
    }
}

@Composable
private fun TextOverlayChip(item: TextOverlay, editMode: Boolean, move: (Float, Float) -> Unit) {
    var offsetX by remember(item.id) { mutableFloatStateOf(0f) }
    var offsetY by remember(item.id) { mutableFloatStateOf(0f) }
    Box(
        Modifier
            .offset {
                IntOffset(
                    (item.x * 900 + offsetX).roundToInt(),
                    (item.y * 1200 + offsetY).roundToInt()
                )
            }
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White.copy(alpha = .72f))
            .border(1.dp, Color.White.copy(alpha = .85f), RoundedCornerShape(12.dp))
            .pointerInput(editMode) {
                if (editMode) {
                    detectDragGestures(
                        onDragEnd = {
                            move(offsetX / 900f, offsetY / 1200f)
                            offsetX = 0f; offsetY = 0f
                        }
                    ) { change, drag ->
                        change.consume()
                        offsetX += drag.x
                        offsetY += drag.y
                    }
                }
            }
            .padding(horizontal = 10.dp, vertical = 7.dp)
    ) {
        Text(item.text, fontSize = item.size.sp, color = Color.Black, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun GlassTop(content: @Composable RowScope.() -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(10.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Color.White.copy(.10f))
            .border(1.dp, Color.White.copy(.18f), RoundedCornerShape(24.dp))
            .padding(4.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

@Composable
private fun GlassBottom(content: @Composable RowScope.() -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(10.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Color.White.copy(.12f))
            .border(1.dp, Color.White.copy(.18f), RoundedCornerShape(24.dp))
            .padding(3.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

@Composable
private fun Glass(modifier: Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(32.dp))
            .background(Brush.linearGradient(listOf(Color.White.copy(.17f), Color.White.copy(.06f))))
            .border(1.dp, Color.White.copy(.20f), RoundedCornerShape(32.dp))
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        content = content
    )
}

@Composable
private fun SmallTool(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector,
                      selected: Boolean = false, onClick: () -> Unit) {
    FilledTonalButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 10.dp)) {
        Icon(icon, null, Modifier.size(17.dp))
        Spacer(Modifier.width(4.dp))
        Text(label, fontSize = 11.sp)
    }
}

private fun share(context: Context, uri: Uri) {
    context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }, "Share PDF"))
}

private fun exportFlattenedPdf(
    context: Context, input: Uri, output: Uri,
    overlays: List<TextOverlay>, count: Int
) {
    val resolver = context.contentResolver
    val pfd = resolver.openFileDescriptor(input, "r") ?: return
    val renderer = PdfRenderer(pfd)
    val doc = android.graphics.pdf.PdfDocument()
    try {
        for (i in 0 until count) {
            val page = renderer.openPage(i)
            val scale = 2
            val bitmap = Bitmap.createBitmap(page.width * scale, page.height * scale, Bitmap.Config.ARGB_8888)
            bitmap.eraseColor(android.graphics.Color.WHITE)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

            val canvas = Canvas(bitmap)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.BLACK
                textSize = 22f * scale
            }
            overlays.filter { it.page == i }.forEach { t ->
                canvas.drawText(t.text, t.x * bitmap.width, t.y * bitmap.height, paint)
            }

            val info = android.graphics.pdf.PdfDocument.PageInfo.Builder(
                bitmap.width, bitmap.height, i + 1
            ).create()
            val outPage = doc.startPage(info)
            outPage.canvas.drawBitmap(bitmap, 0f, 0f, null)
            doc.finishPage(outPage)
            bitmap.recycle()
            page.close()
        }
        resolver.openOutputStream(output)?.use { doc.writeTo(it) }
    } finally {
        doc.close()
        renderer.close()
        pfd.close()
    }
}
