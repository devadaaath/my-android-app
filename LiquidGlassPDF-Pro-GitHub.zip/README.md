# Liquid Glass PDF Pro 2.0

GitHub Actions-ready Android PDF viewer.

## Included
- Open local PDFs
- Native PdfRenderer rendering
- Page navigation + page slider
- Zoom controls
- Rotate
- Fit/reset controls
- Share
- Save/export
- Dark/light appearance
- Liquid-glass UI
- Add text overlays
- Drag text overlays
- Flatten text overlays into a new exported PDF
- Page jump dialog

## Important: text editing
This version does **not rewrite the original PDF text objects**. The Edit Text tool adds editable text overlays and the Save action flattens those overlays into a new PDF. This is reliable with Android's built-in PDF renderer and avoids proprietary PDF SDK requirements.

True character-level editing of existing PDF text (select a word, change it, preserve original typography and reflow) requires a dedicated PDF editing engine and is a separate upgrade.

## Build
Push the project to GitHub, then:
Actions → Build Liquid Glass PDF Pro → Run workflow.
Download the `liquid-glass-pdf-pro-debug` artifact and install the APK.

## Next upgrades
- PDF text extraction/search
- Bookmarks and recent files
- Thumbnails
- Highlight/underline/strikethrough
- Freehand pen
- Eraser
- Image/signature insertion
- Password/encrypted PDF support
- Better responsive overlay coordinates
- True PDF object/text editing engine
